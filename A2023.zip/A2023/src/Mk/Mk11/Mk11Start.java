package Mk.Mk11;

/*
    2023.02.09-2023.

 */


public class Mk11Start {
    public static void main(String[] args) {
        new Mk11Login();
    }
}
